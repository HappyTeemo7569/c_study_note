#ifndef _DEV_CTRL_H_
#define _DEV_CTRL_H_


#ifdef __cplusplus
extern "C" {
#endif


int led_ctrl(int state);


#ifdef __cplusplus
}
#endif


#endif
